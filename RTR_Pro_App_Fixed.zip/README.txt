RTR — Risk To Reward
PROTOTYPE BUILD

Open index.html in a modern browser.

Demo login:
Email: coach@rtr.demo
Password: demo

This prototype stores demo data in the browser only. It is not yet a production service:
- no real authentication
- no cloud database
- no real student accounts
- no server-side security

Next production steps: Supabase/Firebase authentication + database, secure storage for screenshots, coach/student roles, hosting, custom domain, backups and production security review.
