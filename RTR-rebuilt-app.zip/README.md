# RTR — Risk To Reward

A Next.js starter for a trading journal and student performance platform.

## 1. Install

```bash
npm install
```

## 2. Supabase

Create a Supabase project, open SQL Editor and run `supabase/schema.sql`.

Then copy `.env.local.example` to `.env.local` and add your Supabase URL and anon key.

## 3. Run

```bash
npm run dev
```

## 4. Deploy to Vercel

Push the entire project to GitHub, import the repository into Vercel, and add:

- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`

The current dashboard includes a working front-end trade journal. Supabase authentication and persistent database saving are the next integration layer.
