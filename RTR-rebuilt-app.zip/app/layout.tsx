import "./globals.css";

export const metadata = {
  title: "RTR — Risk To Reward",
  description: "Trading performance and psychology tracker"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}