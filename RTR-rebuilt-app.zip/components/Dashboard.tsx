use client";

import { useMemo, useState } from "react";

type Trade = {
  id: number;
  pair: string;
  direction: "LONG" | "SHORT";
  entry: number;
  stop: number;
  target: number;
  result: "WIN" | "LOSS" | "BE";
  feeling: string;
};

const initialTrades: Trade[] = [
  { id: 1, pair: "XAUUSD", direction: "LONG", entry: 3382, stop: 3372, target: 3412, result: "WIN", feeling: "Confident" },
  { id: 2, pair: "NAS100", direction: "SHORT", entry: 23450, stop: 23520, target: 23240, result: "LOSS", feeling: "Hesitant" },
  { id: 3, pair: "EURUSD", direction: "LONG", entry: 1.165, stop: 1.162, target: 1.174, result: "WIN", feeling: "Calm" }
];

export default function Dashboard() {
  const [trades, setTrades] = useState<Trade[]>(initialTrades);
  const [showForm, setShowForm] = useState(false);

  const stats = useMemo(() => {
    const wins = trades.filter(t => t.result === "WIN").length;
    const losses = trades.filter(t => t.result === "LOSS").length;
    const decided = wins + losses;
    return {
      wins,
      losses,
      winRate: decided ? Math.round((wins / decided) * 100) : 0,
      trades: trades.length
    };
  }, [trades]);

  function addTrade(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const trade: Trade = {
      id: Date.now(),
      pair: String(form.get("pair") || "UNKNOWN").toUpperCase(),
      direction: String(form.get("direction")) as "LONG" | "SHORT",
      entry: Number(form.get("entry")),
      stop: Number(form.get("stop")),
      target: Number(form.get("target")),
      result: String(form.get("result")) as Trade["result"],
      feeling: String(form.get("feeling") || "Not recorded")
    };
    setTrades(prev => [trade, ...prev]);
    setShowForm(false);
    e.currentTarget.reset();
  }

  return (
    <main className="shell">
      <header className="topbar">
        <div>
          <div className="brand">RTR<span>.</span></div>
          <div className="tagline">RISK TO REWARD</div>
        </div>
        <button className="primary" onClick={() => setShowForm(v => !v)}>
          {showForm ? "Close" : "+ Log Trade"}
        </button>
      </header>

      <section className="hero">
        <div>
          <p className="eyebrow">TRADING PERFORMANCE</p>
          <h1>Welcome back.</h1>
          <p className="muted">Track the trade. Track the mindset. Improve the trader.</p>
        </div>
      </section>

      <section className="stats">
        <Stat label="Total Trades" value={stats.trades} />
        <Stat label="Win Rate" value={`${stats.winRate}%`} />
        <Stat label="Wins" value={stats.wins} />
        <Stat label="Losses" value={stats.losses} />
      </section>

      {showForm && (
        <form className="card form" onSubmit={addTrade}>
          <h2>Log a trade</h2>
          <div className="grid">
            <label>Pair<input name="pair" placeholder="XAUUSD" required /></label>
            <label>Direction<select name="direction"><option>LONG</option><option>SHORT</option></select></label>
            <label>Entry<input name="entry" type="number" step="any" required /></label>
            <label>Stop Loss<input name="stop" type="number" step="any" required /></label>
            <label>Take Profit<input name="target" type="number" step="any" required /></label>
            <label>Result<select name="result"><option>WIN</option><option>LOSS</option><option>BE</option></select></label>
            <label className="wide">How did you feel?<input name="feeling" placeholder="Confident, nervous, patient..." /></label>
          </div>
          <button className="primary" type="submit">Save Trade</button>
        </form>
      )}

      <section className="content">
        <div className="card">
          <div className="cardhead">
            <div>
              <p className="eyebrow">JOURNAL</p>
              <h2>Recent trades</h2>
            </div>
            <span className="pill">{trades.length} trades</span>
          </div>

          <div className="table">
            <div className="row head">
              <span>PAIR</span><span>SETUP</span><span>R:R</span><span>RESULT</span><span>FEELING</span>
            </div>
            {trades.map(t => {
              const risk = Math.abs(t.entry - t.stop);
              const reward = Math.abs(t.target - t.entry);
              const rr = risk ? (reward / risk).toFixed(1) : "0.0";
              return (
                <div className="row" key={t.id}>
                  <strong>{t.pair}</strong>
                  <span className="direction">{t.direction}</span>
                  <span>1:{rr}</span>
                  <span className={`result ${t.result.toLowerCase()}`}>{t.result}</span>
                  <span className="muted">{t.feeling}</span>
                </div>
              );
            })}
          </div>
        </div>

        <div className="card psychology">
          <p className="eyebrow">TRADER MINDSET</p>
          <h2>Psychology matters.</h2>
          <p className="muted">RTR records how you felt before and after each trade, so you can spot patterns between your mindset and your results.</p>
          <div className="quote">“A good trade is a good trade, even when it loses.”</div>
        </div>
      </section>
    </main>
  );
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="card stat">
      <span className="muted">{label}</span>
      <strong>{value}</strong>
    </div>
  );
}